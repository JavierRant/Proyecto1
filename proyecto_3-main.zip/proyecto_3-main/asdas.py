import cv2

img_1 = cv2.imread('C:/Users/martu/OneDrive/Escritorio/Tercero/VisArt/visionArtificial-master/static/images/levadura.png')
cv2.namedWindow("Image")
cv2.imshow("Image", img_1)
cv2.waitKey(0)

