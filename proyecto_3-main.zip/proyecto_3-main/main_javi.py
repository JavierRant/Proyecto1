# importar bibliotecas
import cv2
import cv2 as cv
import numpy as np
import matplotlib
from scipy import ndimage
from skimage import io, color, measure

# definicion de variables
maxValue = 100
minValue = 0
windowName1 = 'levadura'
windowName2 = 'mapa de color'
trackbarName = 'umbral'

img_1 = cv.imread('C:/Users/martu/OneDrive/Escritorio/Tercero/VisArt/visionArtificial-master/static/images/levadura.png')
#img_1 = cv.resize(img_1, (355, 405))

img = cv.cvtColor(img_1, cv.COLOR_BGR2GRAY)

# creación de la función recursiva que llama la funcion createTrackbar()
def segementation(trackbarValue):
    _, thresh = cv.threshold(img, trackbarValue, maxValue, cv.THRESH_BINARY)

    # Noise removal
    kernel = np.ones((3, 3), np.uint8)
    #matriz 3x3 que analiza el pixel y sus alrededores
    opening = cv.morphologyEx(thresh, cv.MORPH_OPEN, kernel, iterations=7)
    #saca ruido blanco
    #el close saca ruido negro y no lo usamos por que no mejora mucho
    #opening: erosión y dilatación

    #sure backgroung, todo lo negro es fondo si o si
    #se vuelve a dilatar
    sure_bg = cv.dilate(opening, kernel, iterations=2) # Esto es background (sure background)

    #calculates the approximate or precise distance from every binary image pixel to the nearest zero pixel.
    #busca el centro, lo encuentra y marca los bordes
    dist_transform = cv.distanceTransform(opening, cv.DIST_L2, 3)
    _, sure_fg = cv.threshold(dist_transform, 0.01*dist_transform.max(), 255, 0)
    #erosiona el opening para asegurar lo de adentro
    sure_fg = np.uint8(sure_fg) # Estas son celulas (sure foreground)


    unknown = cv.subtract(sure_bg, sure_fg) # pixeles q no sabemos q son exactamente
    #diferencia entre el backgroung y el foreground

    # individualizacion de las celulas
    num, markers = cv.connectedComponents(sure_fg)
    # aprovechamos el hecho de que la funcion connectedComponentes() nos
    # devuelve la cantidad de etiquetas para contar las celulas
    strNUM = str(num-1) # para que no cuente el fondo
    cantCelulas = 'cant celulas:'+ strNUM

    markers = markers+1

    markers[unknown == 255] = 0

    markers = cv.watershed(img_1, markers)

    img_1[markers == -1] = [0, 255, 255]

    labelIMG = np.uint8(255 * markers / num) # convertir los labels en mapa de semillas

    colorMap = cv.applyColorMap(labelIMG, cv.COLORMAP_JET) # crea el mapa de marcadores

    cv.putText(thresh, cantCelulas, (30, 700), cv.FONT_HERSHEY_SIMPLEX , 1, 255)  # muestra la imagen actualizada con los valores de threshold

    clusters = measure.regionprops(label_image=labelIMG, intensity_image=img_1) # para medir el area

    cv.imshow(windowName1, thresh)
    cv.imshow(windowName2, colorMap)
    # cv.imshow("Opening", opening)
    # cv.imshow("Sure background", sure_bg)
    # cv.imshow("Sure foreground", sure_fg)
    # cv.imshow("Unkown", unknown)

# crea el trackbar y lo asocia a la imagen
cv.namedWindow(windowName1)



cv.createTrackbar(trackbarName, windowName1, minValue, maxValue, segementation)

segementation(0)

cv.waitKey(0)